<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class autok extends Model
{
    protected $table = "autok";
    public $timestamps = false;
}
