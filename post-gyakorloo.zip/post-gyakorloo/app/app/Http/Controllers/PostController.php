<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\tanulok;
use App\Models\autok;

class PostController extends Controller
{
    public function Tanulok() {
        return view("welcome", [
            "result"    => tanulok::all(),
            "agazat"    => ["Elektonika és elektrotechnika", "Informatika és távközlés", "Rendészet és közszolgálat"]
        ]);
    }

    public function TanulokButton(Request $req) {
        $req->validate([
            'nev'           => 'required',
            'lakhely'       => 'required',
            'nem'           => 'required'
        ], [
            '*.required'    => "Kötelező megadni!"
        ]);

        $data = new tanulok;
        $data->nev = $req->nev;
        $data->kor = $req->kor;
        $data->lakhely = $req->lakhely;
        $data->nem = $req->nem;
        $data->agazat = $req->agazat;

        $data->Save();

        return redirect('/');

    }

    public function Autok() {
        return view("autok", [
            "result"    => autok::all()
        ]);
    }
} 
