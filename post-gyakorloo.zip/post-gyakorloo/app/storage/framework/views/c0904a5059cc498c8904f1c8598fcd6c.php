<svg width="10" height="10" viewBox="0 0 10 10" fill="none" xmlns="http://www.w3.org/2000/svg" <?php echo e($attributes); ?>>
    <path d="M4.75 1L0.75 5L4.75 9" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"/>
    <path d="M9.25 1L5.25 5L9.25 9" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"/>
</svg>
<?php /**PATH C:\Users\csiha.mark\Desktop\post-gyakorloo\app\vendor\laravel\framework\src\Illuminate\Foundation\Providers/../resources/exceptions/renderer/components/icons/chevrons-left.blade.php ENDPATH**/ ?>