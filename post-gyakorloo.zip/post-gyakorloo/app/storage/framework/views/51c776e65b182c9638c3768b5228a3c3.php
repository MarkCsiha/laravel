
<?php $__env->startSection("content"); ?>
    <main class="container py-4 px-5">
        <section>
            <h1>Tanuló hozzáadása</h1>
            
                <div class="col-md">
                    <table class="table table-bordered table-striped">
                        <tr>
                            <th>Név</th>
                            <th>Kor</th>
                            <th>Lakhely</th>
                            <th>Nem</th>
                            <th>Ágazat</th>
                        </tr>
                        <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($row->nev); ?></td>
                                <td><?php echo e($row->kor); ?></td>
                                <td><?php echo e($row->lakhely); ?></td>
                                <td><?php if($row->nem == 'f'): ?> férfi <?php else: ?> nő <?php endif; ?></td>
                                <td><?php echo e($row->agazat); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                </div>
        </section>
    </main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layout", array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\csiha.mark\Desktop\post-gyakorloo\app\resources\views/autok.blade.php ENDPATH**/ ?>