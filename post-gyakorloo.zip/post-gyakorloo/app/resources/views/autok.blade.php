@extends("layout")
@section("content")
    <main class="container py-4 px-5">
        <section>
            <h1>Tanuló hozzáadása</h1>
            {{-- <div class="row">
                <div class="col-md">
                    <div class="card">
                        <div class="card-body">
                            <form action="/" method="post">
                            @csrf
                            <label class="form-label fw-bold mt-4" for="rendszam">Autó rendszáma: </label>
                            <input class="form-control" type="text" name="rendszam" id="rendszam" value="{{old('rendszam')}}"> 
                            @error('nev')
                                <p class="text-danger">{{ $message }}</p>
                            @enderror

                            <label for="marka" class="form-label mt-4 fw-bold">Autó márkája: </label>
                            <select class="form-select" name="marka" id="marka">
                                @for ($i = 14; $i < 24; $i++) 
                                    <option value="{{$i}}" @if(old('marka') == $i) selected @endif>{{$i}} év</option>        
                                @endfor
                            </select>
                            <label class="form-label mt-4 fw-bold" for="tipus">Autó típusa: </label>
                            <input class="form-control" type="text" name="tipus" id="tipus" value="{{old('tipus')}}"> 
                            @error('tipus')
                                <p class="text-danger">{{ $message }}</p>
                            @enderror

                            <div>
                            <p class="form-label fw-bold">Tanuló neme: </p>
                            <input class="form-check-input" type="radio" name="nem" id="nemf" value="f" @if(old('nem') == 'f') checked @endif>
                            <label for="nemf" class="form-check-label">Férfi</label> &nbsp;  &nbsp;  &nbsp;
                            <input class="form-check-input" type="radio" name="nem" id="nemn" value="n" @if(old('nem') == 'n') checked @endif>
                            <label for="nemn" class="form-check-label">Nő</label>
                            </div>
                            @error('nem')
                                <p class="text-danger">{{$message}}</p>
                            @enderror
                            <label for="agazat" class="form-label mt-4 fw-bold">Tanuló ágazata: </label>
                            <select class="form-select" name="agazat" id="agazat">
                                @for ($i = 0; $i < count($agazat); $i++) 
                                    <option value="{{$agazat[$i]}}" @if(old('agazat') == $agazat[$i]) selected @endif>{{$agazat[$i]}}</option>
                                
                                @endfor
                                
                            </select>


                            <button class="btn btn-dark" type="submit">Elküld</button>

                        </form>
                        </div>
                    </div>
                </div>
                 --}}
                <div class="col-md">
                    <table class="table table-bordered table-striped">
                        <tr>
                            <th>Név</th>
                            <th>Kor</th>
                            <th>Lakhely</th>
                            <th>Nem</th>
                            <th>Ágazat</th>
                        </tr>
                        @foreach ($result as $row)
                            <tr>
                                <td>{{$row->nev}}</td>
                                <td>{{$row->kor}}</td>
                                <td>{{$row->lakhely}}</td>
                                <td>@if($row->nem == 'f') férfi @else nő @endif</td>
                                <td>{{$row->agazat}}</td>
                            </tr>
                        @endforeach
                    </table>
                </div>
        </section>
    </main>
@endsection