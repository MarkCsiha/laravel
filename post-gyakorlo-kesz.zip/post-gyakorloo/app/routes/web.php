<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\PostController;

// Route::get('/', function () {
//     return view('welcome');
// });

Route::get('/',  [PostController::class, "Tanulok"]);
Route::post('/',  [PostController::class, "TanulokButton"]);

Route::get('/autok', [PostController::class, "Autok"]);
Route::post("/autok", [PostController::class, "AutokButton"]);

Route::get("/klippek", [PostController::class, "Klippek"]);
Route::post("/klippek", [PostController::class, "KlippekButton"]);

Route::get('/szallitas', [PostController::class, "Szallitas"]);
Route::post('/szallitas', [PostController::class, "SzallitasButton"]);

Route::get('/szinesz', [PostController::class, "Szinesz"]);
Route::post('/szinesz', [PostController::class, "SzineszButton"]);