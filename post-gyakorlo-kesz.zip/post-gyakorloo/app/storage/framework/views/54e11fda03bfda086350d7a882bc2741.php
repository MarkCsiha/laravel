
<?php $__env->startSection("content"); ?>
    <main class="container py-4 px-5">
        <section>
            <h1>Színész hozzáadása</h1>
            <?php if(session('msg')): ?>   
                <p class="text-success"><?php echo e(session('msg')); ?></p>
            <?php endif; ?>
            <div class="row">
                <div class="col-md">
                    <div class="card-body">
                        <form action="/szinesz" method="post">
                            <?php echo csrf_field(); ?>
                            <label class="form-label fw-bold mt-4" for="nev">Színész neve: </label>
                            <input class="form-control" type="text" name="nev" id="nev" value="<?php echo e(old('nev')); ?>">
                            <?php $__errorArgs = ["nev"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="text-danger"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                            <label for="szuletes" class="form-label fw-bold mt-4">Születési ideje: </label>
                            <input type="date" class="form-control" name="szuletes" id="szuletes" value="<?php echo e(old('szuletes')); ?>" min="1900-01-01">

                            <?php $__errorArgs = ["szuletes"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="text-danger"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                            <label for="nemzet" class="form-label fw-bold mt-4">Nemzete: </label>
                            <input type="text" class="form-control" name="nemzet" id="nemzet" value="<?php echo e(old('nemzet')); ?>">

                            <?php $__errorArgs = ["nemzet"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-danger"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                            <div class="mb-2 mt-3">
                                <input class="form-check-input" type="checkbox" name="oscardijas" id="oscardijas">
                                <label class="form-check-label" for="oscardijas">Oscar díjas?</label>
                            </div>

                            <button class="btn btn-dark mt-4" type="submit">Elküld</button>
                        </form>
                    </div>
                </div>
            
                <div class="col-md">
                    <table class="table table-bordered table-striped">
                        <tr>
                            <th>Név</th>
                            <th>Születési idő</th>
                            <th>Nemzet</th>
                            <th>Oscar-díj</th>
                        </tr>
                        <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($row->nev); ?></td>
                                <td><?php echo e($row->szuletes); ?></td>
                                <td><?php echo e($row->nemzet); ?></td>
                                <td><?php echo e($row->oscar_dij); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                </div>
        </section>
    </main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layout", array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\csiha.mark\Desktop\post-gyakorloo\app\resources\views/szinesz.blade.php ENDPATH**/ ?>