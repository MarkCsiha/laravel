
<?php $__env->startSection("content"); ?>
    <main class="container py-4 px-5">
        <section>
            <h1>Klipp hozzáadása</h1>
            <div class="row">
                <div class="col-md">
                    <div class="card-body">
                        <form action="/klippek" method="post" class="form form-striped">
                            <?php echo csrf_field(); ?>
                            <div class="mb-3">
                                <label for="eloado" class="form-label fw-bold mt-4">Előadó neve: </label>
                                <input type="text" name="eloado" id="eloado" class="form-control" value="<?php echo e(old('eloado')); ?>">

                                <?php $__errorArgs = ["eloado"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="text-success"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                <label for="cim" class="form-label fw-bold mt-4">Szám címe: </label>
                                <input type="text" name="cim" id="cim" class="form-control" value="<?php echo e(old('cim')); ?>">

                                <?php $__errorArgs = ['cim'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="text-success"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <p class="form-label">Szám hossza:</p>
                                <div class="d-flex mb-3">
                                    <div class="w-50 pe-2">
                                        <select class="form-select" name="min" id="min">
                                            <?php for($i=1;$i<=10;$i++): ?>
                                                <option value="<?php echo e($i); ?>"><?php echo e($i.' perc'); ?></option>
                                            <?php endfor; ?>
                                        </select>
                                    </div>
                                    
                                    <div class="w-50 ps-2">
                                        <select class="form-select" name="sec" id="sec">
                                            <?php for($i=0;$i<=59;$i++): ?>
                                                <option value="<?php echo e($i); ?>"><?php echo e($i.' másodperc'); ?></option>
                                            <?php endfor; ?>
                                        </select>
                                    </div>
                                </div>

                                <div class="mb-3">
                                    <label for="youtube" class="form-label fw-bold mt-4">Youtube link: </label>
                                    <input type="text" name="youtube" id="youtube" class="form-control" value="<?php echo e(old('youtube')); ?>">
    
                                    <?php $__errorArgs = ['youtube'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <p class="text-success"><?php echo e($message); ?></p>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <button class="btn btn-dark mt-4" type="submit">Elküld</button>
                        </form>
                    </div>
                </div>
                <div class="col-md">
                    <table class="table table-bordered table-striped">
                        <tr>
                            <th>Klipp</th>
                            <th>Hossz</th>
                            <th>YouTube link</th>
                        </tr>
                        <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($row->eloado.' - '.$row->cim); ?></td>
                            <td><?php echo e(substr($row->hossz, 3, 5)); ?></td>
                            <td><a href="<?php echo e($row->youtube); ?>" target="_blank"><?php echo e($row->youtube); ?></a></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                </div>
            </div>
        </section>
    </main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layout", array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\csiha.mark\Desktop\post-gyakorloo\app\resources\views/klippek.blade.php ENDPATH**/ ?>