
<?php $__env->startSection("content"); ?>
    <main class="container py-4 px-5">
        <section>
            <h1>Házhozszállítás</h1>
            <?php if(session('msg')): ?> 
                <p class="text-success"><?php echo e(session('msg')); ?></p>
            <?php endif; ?>
            <div class="row">
                <div class="col-md">
                    <div class="card">
                        <div class="card-body">
                            <form action="/szallitas" method="post">
                            <?php echo csrf_field(); ?>
                            <div class="mb-2">
                                <label class="form-label fw-bold mt-4" for="nev">Név: <span class="text-danger">*</span> </label>
                                <input class="form-control <?php $__errorArgs = ['nev'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text" name="nev" id="nev" value="<?php echo e(old('nev')); ?>"> 
                            </div>
                            <div class="row">
                                <div class="col-md-4">
                                    <label class="form-label fw-bold mt-4" for="irsz">Irányítószám:<span class="text-danger">*</span> </label>
                                    <input class="form-control <?php $__errorArgs = ['irsz'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text" name="irsz" id="irsz" value="<?php echo e(old('irsz')); ?>"> 
                                </div>
                                <div class="col-md-8">
                                    <label class="form-label fw-bold mt-4" for="varos">Város: <span class="text-danger">*</span> </label>
                                    <input class="form-control <?php $__errorArgs = ['irsz'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text" name="varos" id="varos" value="<?php echo e(old('varos')); ?>"> 
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-8">
                                    <label class="form-label fw-bold mt-4" for="utca">Utca:<span class="text-danger">*</span> </label>
                                    <input class="form-control <?php $__errorArgs = ['utca'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text" name="utca" id="utca" value="<?php echo e(old('utca')); ?>"> 
                                </div>
                                <div class="col-md-4">
                                    <label class="form-label fw-bold mt-4" for="hazszam">Házszám: <span class="text-danger">*</span> </label>
                                    <input class="form-control <?php $__errorArgs = ['hazszam'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text" name="hazszam" id="hazszam" value="<?php echo e(old('hazszam')); ?>"> 
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-8">
                                    <label class="form-label fw-bold mt-4" for="emelet">Emelet: </label>
                                    <select class="form-select" name="emelet" id="emelet">
                                        <option value="0">---</option>
                                        <option value="fsz">Földszint</option>
                                        <?php for($i = 1; $i<31;$i++): ?>
                                            <option value="<?php echo e($i); ?>"><?php echo e($i.' emelet'); ?></option>
                                        <?php endfor; ?>
                                    </select> 
                                </div>
                                <div class="col-md-4">
                                    <label class="form-label fw-bold mt-4" for="ajto">Ajtó: <span class="text-danger">*</span> </label>
                                    <input class="form-control" type="number" name="ajto" id="ajto" value="<?php echo e(old('ajto')); ?>"> 
                                </div>

                                
                            </div>
                            <p class="form-label">Telefonszám: <span style="color: red;">*</span></p>
                            <div class="row">
                                <div class="col-md-4">   
                                    <select class="form-select" name="korzet" id="korzet">
                                        <option value="20">20</option>
                                        <option value="30">30</option>
                                        <option value="70">70</option>
                                    </select> 
                                </div>
                                <div class="col-md-8">
                                    <input class="form-control" type="text" name="tel" id="tel" value="<?php echo e(old('tel')); ?>" placeholder="pl.:1234567"> 
                                </div>
                                <?php $__errorArgs = ['tel'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="text-danger"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="mb-2 mt-3">
                                <input class="form-check-input" type="checkbox" name="erintesmentes" id="erintesmentes">
                                <label class="form-check-label" for="erintesmentes">Érintésmentes szállítás</label>
                            </div>
                            <p class="text-danger">* Kötelező kitölteni </p>
                            <button class="btn btn-dark mt-4" type="submit">Elküld</button>


                            

                        </form>
                        </div>
                    </div>
                </div>
                
                <div class="col-md">
                    <table class="table table-bordered table-striped">
                        <tr>
                            <th>Név</th>
                            <th>Cím</th>
                            <th>Telefonszám</th>
                            <th>Érintésmentes</th>
                        </tr>
                        <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($row->nev); ?></td>
                                <td>
                                    <?php echo e($row->irsz.' '.$row->varos.', '.$row->utca.' '.$row->hazszam.'.'); ?>

                                    <?php if($row->emelet <> "" || $row->ajto <> ""): ?>
                                        -
                                        <?php if($row->emelet == "fsz"): ?>
                                            <?php echo e($row->emelet.'. '); ?>

                                        <?php else: ?>
                                            <?php echo e($row->emelet.'. en'); ?>

                                        <?php endif; ?>
                                        <?php echo e($row->ajto); ?>

                                    <?php endif; ?>
                                    
                                </td>
                                <td><?php echo e($row->telefonszam); ?></td>
                                <td><?php if($row->erintesmentes == 'i'): ?> igen <?php else: ?> nem <?php endif; ?></td>
                                                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                </div>
        </section>
    </main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layout", array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\csiha.mark\Desktop\post-gyakorloo\app\resources\views/szallitas.blade.php ENDPATH**/ ?>