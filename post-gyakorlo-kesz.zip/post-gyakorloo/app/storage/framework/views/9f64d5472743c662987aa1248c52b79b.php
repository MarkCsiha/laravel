<?php $__env->startSection("content"); ?>
    <main class="container py-4 px-5">
        <section>
            <h1>Tanuló hozzáadása</h1>
            <div class="row">
                <div class="col-md">
                    <div class="card">
                        <div class="card-body">
                            <form action="/" method="post">
                            <?php echo csrf_field(); ?>
                            <label class="form-label fw-bold mt-4" for="nev">Tanuló neve: </label>
                            <input class="form-control" type="text" name="nev" id="nev" value="<?php echo e(old('nev')); ?>"> 
                            <?php $__errorArgs = ['nev'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="text-danger"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                            <label for="kor" class="form-label mt-4 fw-bold">Tanuló kora: </label>
                            <select class="form-select" name="kor" id="kor">
                                <?php for($i = 14; $i < 24; $i++): ?> 
                                    <option value="<?php echo e($i); ?>" <?php if(old('kor') == $i): ?> selected <?php endif; ?>><?php echo e($i); ?> év</option>        
                                <?php endfor; ?>
                            </select>
                            <label class="form-label mt-4 fw-bold" for="lakhely">Tanuló lakhelye: </label>
                            <input class="form-control" type="text" name="lakhely" id="lakhely" value="<?php echo e(old('lakhely')); ?>"> 
                            <?php $__errorArgs = ['lakhely'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="text-danger"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                            <div>
                            <p class="form-label fw-bold">Tanuló neme: </p>
                            <input class="form-check-input" type="radio" name="nem" id="nemf" value="f" <?php if(old('nem') == 'f'): ?> checked <?php endif; ?>>
                            <label for="nemf" class="form-check-label">Férfi</label> &nbsp;  &nbsp;  &nbsp;
                            <input class="form-check-input" type="radio" name="nem" id="nemn" value="n" <?php if(old('nem') == 'n'): ?> checked <?php endif; ?>>
                            <label for="nemn" class="form-check-label">Nő</label>
                            </div>
                            <?php $__errorArgs = ['nem'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="text-danger"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <label for="agazat" class="form-label mt-4 fw-bold">Tanuló ágazata: </label>
                            <select class="form-select" name="agazat" id="agazat">
                                <?php for($i = 0; $i < count($agazat); $i++): ?> 
                                    <option value="<?php echo e($agazat[$i]); ?>" <?php if(old('agazat') == $agazat[$i]): ?> selected <?php endif; ?>><?php echo e($agazat[$i]); ?></option>
                                
                                <?php endfor; ?>
                                
                            </select>


                            <button class="btn btn-dark" type="submit">Elküld</button>

                        </form>
                        </div>
                    </div>
                </div>
                
                <div class="col-md">
                    <table class="table table-bordered table-striped">
                        <tr>
                            <th>Név</th>
                            <th>Kor</th>
                            <th>Lakhely</th>
                            <th>Nem</th>
                            <th>Ágazat</th>
                        </tr>
                        <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($row->nev); ?></td>
                                <td><?php echo e($row->kor); ?></td>
                                <td><?php echo e($row->lakhely); ?></td>
                                <td><?php if($row->nem == 'f'): ?> férfi <?php else: ?> nő <?php endif; ?></td>
                                <td><?php echo e($row->agazat); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                </div>
        </section>
    </main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layout", array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\csiha.mark\Desktop\post-gyakorloo\app\resources\views/welcome.blade.php ENDPATH**/ ?>