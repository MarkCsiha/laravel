<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class tanulok extends Model
{
    protected $table = "tanulok";
    public $timestamps = false;
}
