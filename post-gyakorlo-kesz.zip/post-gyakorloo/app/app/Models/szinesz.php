<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class szinesz extends Model
{
    protected $table = "szinesz";
    public $timestamps = false;
}
