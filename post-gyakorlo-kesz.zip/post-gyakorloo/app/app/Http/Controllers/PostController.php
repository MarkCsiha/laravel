<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\tanulok;
use App\Models\autok;
use App\Models\klippek;
use App\Models\szallitas;
use App\Models\szinesz;

class PostController extends Controller
{
    public function Tanulok() {
        return view("welcome", [
            "result"    => tanulok::all(),
            "agazat"    => ["Elektonika és elektrotechnika", "Informatika és távközlés", "Rendészet és közszolgálat"]
        ]);
    }

    public function TanulokButton(Request $req) {
        $req->validate([
            'nev'           => 'required',
            'lakhely'       => 'required',
            'nem'           => 'required'
        ], [
            '*.required'    => "Kötelező megadni!"
        ]);

        $data = new tanulok;
        $data->nev = $req->nev;
        $data->kor = $req->kor;
        $data->lakhely = $req->lakhely;
        $data->nem = $req->nem;
        $data->agazat = $req->agazat;

        $data->Save();

        return redirect('/');

    }

    public function Autok() {
        return view("autok", [
            "result"    => autok::all()
            
        ]);
    }

    public function AutokButton(Request $req) {
        $req->validate([
            'rendszam'  => "required|min:6|max:10",
            'marka'     => "required",
            'tipus'     => "required",
            "szin"      => "required"
        ], [
            "*.required"    => "Kötelező megadni!",
            '*.min:6'       => "Legalább 6 karakter hosszúságú legyen!",
            '*.max:10'      => "Maximum 10 karakter hossszúságú lehet!"
        ]);
        
        $data = new autok;
        $data->rendszam = $req->rendszam;
        $data->marka = $req->nagybetu;
        
        $data->tipus = $req->tipus;
        $data->szin = $req->szin;
        $data->evjarat = $req->evjarat;

        $data->Save();

        return redirect('/autok');
    }

    public function Klippek() {
        return view("klippek", [
            "result"    => klippek::all()
        ]);
    }

    public function KlippekButton(Request $req) {
        $req->validate([
            'eloado'    => "required",
            'cim'       => "required",
            'youtube'   => "required|active_url"
        ],[
            '*.required'    => "Kötelező megadni!",
            '*.active_url'  => "Létező linket adjon meg!"
        ]);

        $data = new klippek;
        $data->eloado = $req->eloado;
        $data->cim = $req->cim;
        $data->youtube = $req->youtube;
        if ($req->min < 10) {
            $min = '0'.$req->min;
        }
        else {
            $min = $req->min;
        }
        if ($req->sec < 10) {
            $sec = '0'.$req->sec;
        }
        else {
            $sec = $req->sec;
        }
        $data->hossz = "00:".$min.":".$sec;

        $data->Save();
        return redirect('/klippek');
    }

    public function Szallitas() {
        return view("szallitas", [
            "result"    => szallitas::all()
        ]);
    }

    public function SzallitasButton(Request $req) {
        $req->validate ([
            "nev"   => "required|min:6",
            "irsz"  => "required|numeric|between:1000,9999",
            "varos" => "required|min:2",
            "utca"  => "required|min:6",
            "hazszam"   => "required",
            "tel"   => "required|numeric|digits:7"
        ],[
            '*.required'=> "Kötelező kitölteni!",
            'tel.numeric'   => "Csak számot adjon meg!",
            'tel.digits'    => "Hét számjegyet adjon meg!"
        ]);

        $data = new szallitas;
        $data->nev = $req->nev;
        $data->irsz = $req->irsz;
        $data->varos = $req->varos;
        $data->utca = $req->utca;
        $data->hazszam = $req->hazszam;
        if ($data->emelet <> 0) {
            $data->emelet = $req->emelet;
        }
        if ($req->ajto) {
            $data->ajto = $req->ajto;
        }
        if ($req->has('erintesmentes')) {
            $data->erintesmentes = 'i';
        }
        else{
            $data->erintesmentes = 'n';
        }
        $data->tel = '+36'.$req->korzet.$req->tel;
        $data->Save();
        return redirect('/szallitas')->with([
            'msg'   => "Sikeresen hozzáadta a címet!"
        ]);
    }

    public function Szinesz() {
        return view("szinesz", [
            "result"    => szinesz::all()
        ]);
    }

    public function SzineszButton(Request $req) {
        $req->validate([
            "nev"   => "required|before:today",
            "szuletes"  => "required",
            "nemzet"   => "required"
        ],[
            '*.required'    => "Kötelező megadni!",
            // '*szuletes.before_or_equal'    => "Mai dátumnál előbbit adjon meg!"
        ]);

        $data = new szinesz;
        $data->nev = $req->nev;
        $data->szuletes = $req->szuletes;
        $data->nemzet = $req->nemzet;
        if ($req->has("oscardijas")) {
            $data->oscar_dij = "i";
        }
        else {
            $data->oscar_dij = "n";
        }

        $data->Save();
        return redirect("/szinesz")->with([
            "msg"   => "Sikeresen hozzáadta a színészt!"
        ]);
    }
} 
