@extends("layout")
@section("content")
    <main class="container py-4 px-5">
        <section>
            <h1>Színész hozzáadása</h1>
            @if (session('msg'))   
                <p class="text-success">{{session('msg')}}</p>
            @endif
            <div class="row">
                <div class="col-md">
                    <div class="card-body">
                        <form action="/szinesz" method="post">
                            @csrf
                            <label class="form-label fw-bold mt-4" for="nev">Színész neve: </label>
                            <input class="form-control" type="text" name="nev" id="nev" value="{{old('nev')}}">
                            @error("nev")
                                <p class="text-danger">{{$message}}</p>
                            @enderror

                            <label for="szuletes" class="form-label fw-bold mt-4">Születési ideje: </label>
                            <input type="date" class="form-control" name="szuletes" id="szuletes" value="{{old('szuletes')}}" min="1900-01-01">

                            @error("szuletes")
                                <p class="text-danger">{{$message}}</p>
                            @enderror

                            <label for="nemzet" class="form-label fw-bold mt-4">Nemzete: </label>
                            <input type="text" class="form-control" name="nemzet" id="nemzet" value="{{old('nemzet')}}">

                            @error("nemzet")
                            <p class="text-danger">{{$message}}</p>
                            @enderror

                            <div class="mb-2 mt-3">
                                <input class="form-check-input" type="checkbox" name="oscardijas" id="oscardijas">
                                <label class="form-check-label" for="oscardijas">Oscar díjas?</label>
                            </div>

                            <button class="btn btn-dark mt-4" type="submit">Elküld</button>
                        </form>
                    </div>
                </div>
            
                <div class="col-md">
                    <table class="table table-bordered table-striped">
                        <tr>
                            <th>Név</th>
                            <th>Születési idő</th>
                            <th>Nemzet</th>
                            <th>Oscar-díj</th>
                        </tr>
                        @foreach ($result as $row)
                            <tr>
                                <td>{{$row->nev}}</td>
                                <td>{{$row->szuletes}}</td>
                                <td>{{$row->nemzet}}</td>
                                <td>{{$row->oscar_dij}}</td>
                            </tr>
                        @endforeach
                    </table>
                </div>
        </section>
    </main>
@endsection