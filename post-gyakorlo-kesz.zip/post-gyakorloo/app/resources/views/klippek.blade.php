@extends("layout")
@section("content")
    <main class="container py-4 px-5">
        <section>
            <h1>Klipp hozzáadása</h1>
            <div class="row">
                <div class="col-md">
                    <div class="card-body">
                        <form action="/klippek" method="post" class="form form-striped">
                            @csrf
                            <div class="mb-3">
                                <label for="eloado" class="form-label fw-bold mt-4">Előadó neve: </label>
                                <input type="text" name="eloado" id="eloado" class="form-control" value="{{old('eloado')}}">

                                @error("eloado")
                                    <p class="text-success">{{$message}}</p>
                                @enderror

                                <label for="cim" class="form-label fw-bold mt-4">Szám címe: </label>
                                <input type="text" name="cim" id="cim" class="form-control" value="{{old('cim')}}">

                                @error('cim')
                                    <p class="text-success">{{$message}}</p>
                                @enderror
                                <p class="form-label">Szám hossza:</p>
                                <div class="d-flex mb-3">
                                    <div class="w-50 pe-2">
                                        <select class="form-select" name="min" id="min">
                                            @for    ($i=1;$i<=10;$i++)
                                                <option value="{{$i}}">{{$i.' perc'}}</option>
                                            @endfor
                                        </select>
                                    </div>
                                    
                                    <div class="w-50 ps-2">
                                        <select class="form-select" name="sec" id="sec">
                                            @for    ($i=0;$i<=59;$i++)
                                                <option value="{{$i}}">{{$i.' másodperc'}}</option>
                                            @endfor
                                        </select>
                                    </div>
                                </div>

                                <div class="mb-3">
                                    <label for="youtube" class="form-label fw-bold mt-4">Youtube link: </label>
                                    <input type="text" name="youtube" id="youtube" class="form-control" value="{{old('youtube')}}">
    
                                    @error('youtube')
                                        <p class="text-success">{{$message}}</p>
                                    @enderror
                                </div>
                            </div>
                            <button class="btn btn-dark mt-4" type="submit">Elküld</button>
                        </form>
                    </div>
                </div>
                <div class="col-md">
                    <table class="table table-bordered table-striped">
                        <tr>
                            <th>Klipp</th>
                            <th>Hossz</th>
                            <th>YouTube link</th>
                        </tr>
                        @foreach ($result as $row)
                        <tr>
                            <td>{{$row->eloado.' - '.$row->cim}}</td>
                            <td>{{substr($row->hossz, 3, 5)}}</td>
                            <td><a href="{{$row->youtube}}" target="_blank">{{$row->youtube}}</a></td>
                        </tr>
                        @endforeach
                    </table>
                </div>
            </div>
        </section>
    </main>
@endsection