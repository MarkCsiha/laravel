
<?php $__env->startSection("content"); ?>
    <main class="container py-4 px-5">
        <section>
            <h1>Autó hozzáadása</h1>
            <div class="row">
                <div class="col-md">
                    <div class="card-body">
                        <form action="/autok" method="post">
                            <?php echo csrf_field(); ?>
                            <label class="form-label fw-bold mt-4" for="rendszam">Autó rendszáma: </label>
                            <input class="form-control" type="text" name="rendszam" id="rendszam" value="<?php echo e(old('rendszam')); ?>" placeholder="PL: AA AA-123">
                            <?php $__errorArgs = ["rendszam"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="text-danger"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                            <label for="marka" class="form-label fw-bold mt-4">Autó márkája: </label>
                            <input type="text" class="form-control" name="marka" id="marka" value="<?php echo e(old('marka')); ?>" placeholder="PL: Ford">

                            <?php $__errorArgs = ["marka"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="text-danger"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                            <label for="tipus" class="form-label fw-bold mt-4">Autó típusa: </label>
                            <input type="text" class="form-control" name="tipus" id="tipus" value="<?php echo e(old('tipus')); ?>" placeholder="PL: Focus">

                            <?php $__errorArgs = ['tipus'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="text-danger"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <label for="evjarat" name='evjarat' class="form-label mt-4 fw-bold">Autó évjárata: </label>
                            <select name="evjarat" id="evjarat" class="form-select">
                                <?php for($i = 2026; $i >= 1960; $i--): ?> {
                                    <option value="<?php echo e($i); ?>" <?php if(old('evjarat') == $i): ?> selected <?php endif; ?>><?php echo e($i); ?></option>
                                } 
                                <?php endfor; ?>
                            </select>

                            <label for="szin" class="form-label fw-bold mt-4">Autó színe: </label>
                            <input type="text" class="form-control" name="szin" id="szin" value="<?php echo e(old('szin')); ?>" placeholder="Pl.: olajzöld">

                            <button class="btn btn-dark mt-4" type="submit">Elküld</button>
                        </form>
                    </div>
                </div>
            
                <div class="col-md">
                    <table class="table table-bordered table-striped">
                        <tr>
                            <th>Rendszám</th>
                            <th>Márka</th>
                            <th>Típus</th>
                            <th>Évjárat</th>
                            <th>Szín</th>
                        </tr>
                        <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($row->rendszam); ?></td>
                                <td><?php echo e($row->marka); ?></td>
                                <td><?php echo e($row->tipus); ?></td>
                                <td><?php echo e($row->evjarat); ?></td>
                                <td><?php echo e($row->szin); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                </div>
        </section>
    </main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layout", array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\csiha.mark\Desktop\post-gyakorloo\app\resources\views/autok.blade.php ENDPATH**/ ?>