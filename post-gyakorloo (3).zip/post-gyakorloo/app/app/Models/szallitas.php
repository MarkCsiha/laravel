<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class szallitas extends Model
{
    protected $table = "szallitas";
    public $timestamps = false;
}
