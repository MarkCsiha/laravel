@extends("layout")
@section("content")
    <main class="container py-4 px-5">
        <section>
            <h1>Házhozszállítás</h1>
            <div class="row">
                <div class="col-md">
                    <div class="card">
                        <div class="card-body">
                            <form action="/szallitas" method="post">
                            @csrf
                            <div class="mb-2">
                                <label class="form-label fw-bold mt-4" for="nev">Név: <span class="text-danger">*</span> </label>
                                <input class="form-control @error('nev') is-invalid @enderror" type="text" name="nev" id="nev" value="{{old('nev')}}"> 
                            </div>
                            <div class="row">
                                <div class="col-md-4">
                                    <label class="form-label fw-bold mt-4" for="irsz">Irányítószám:<span class="text-danger">*</span> </label>
                                    <input class="form-control @error('irsz') is-invalid @enderror" type="text" name="irsz" id="irsz" value="{{old('irsz')}}"> 
                                </div>
                                <div class="col-md-8">
                                    <label class="form-label fw-bold mt-4" for="varos">Város: <span class="text-danger">*</span> </label>
                                    <input class="form-control @error('irsz') is-invalid @enderror" type="text" name="varos" id="varos" value="{{old('varos')}}"> 
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-8">
                                    <label class="form-label fw-bold mt-4" for="utca">Utca:<span class="text-danger">*</span> </label>
                                    <input class="form-control @error('utca') is-invalid @enderror" type="text" name="utca" id="utca" value="{{old('utca')}}"> 
                                </div>
                                <div class="col-md-4">
                                    <label class="form-label fw-bold mt-4" for="hazszam">Házszám: <span class="text-danger">*</span> </label>
                                    <input class="form-control @error('hazszam') is-invalid @enderror" type="text" name="hazszam" id="hazszam" value="{{old('hazszam')}}"> 
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-8">
                                    <label class="form-label fw-bold mt-4" for="emelet">Emelet: </label>
                                    <select class="form-select" name="emelet" id="emelet">
                                        <option value="">---</option>
                                        <option value="fsz">Földszint</option>
                                        @for ($i = 1; $i<31;$i++)
                                            <option value="{{$i}}">{{$i.' emelet'}}</option>
                                        @endfor
                                    </select> 
                                </div>
                                <div class="col-md-4">
                                    <label class="form-label fw-bold mt-4" for="ajto">Ajtó: <span class="text-danger">*</span> </label>
                                    <input class="form-control" type="number" name="ajto" id="ajto" value="{{old('ajto')}}"> 
                                </div>
                            </div>
                            <p class="form-label">Telefonszám: <span style="color: red;">*</span></p>
                            <div class="row">
                                <div class="col-md-4">   
                                    <select class="form-select" name="korzet" id="korzet">
                                        <option value="20">20</option>
                                        <option value="30">30</option>
                                        <option value="70">70</option>
                                    </select> 
                                </div>
                                <div class="col-md-8">
                                    <input class="form-control" type="text" name="tel" id="tel" value="{{old('tel')}}" placeholder="pl.:1234567"> 
                                </div>
                            </div>
                            <div class="mb-2 mt-3">
                                <input class="form-check-input" type="checkbox" name="erintesmentes" id="erintesmentes">
                                <label class="form-check-label" for="erintesmentes">Érintésmentes szállítás</label>
                            </div>
                            <p class="text-danger">* Kötelező kitölteni </p>
                            <button class="btn btn-dark mt-4" type="submit">Elküld</button>


                            

                        </form>
                        </div>
                    </div>
                </div>
                
                <div class="col-md">
                    <table class="table table-bordered table-striped">
                        <tr>
                            <th>Név</th>
                            <th>Cím</th>
                            <th>Telefonszám</th>
                            <th>Érintésmentes</th>
                        </tr>
                        @foreach ($result as $row)
                            <tr>
                                <td>{{$row->nev}}</td>
                                <td>
                                    {{$row->irsz.' '.$row->varos.', '.$row->utca.' '.$row->hazszam.'.'}}
                                    @if ($row->emelet <> "" || $row->ajto <> "")
                                        -
                                        @if($row->emelet == "fsz")
                                            {{$row->emelet.'. '}}
                                        @else
                                            {{$row->emelet.'. en'}}
                                        @endif
                                        {{$row->ajto}}
                                    @endif
                                    
                                </td>
                                <td>{{$row->telefonszam}}</td>
                                <td>@if($row->erintesmentes == 'i') igen @else nem @endif</td>
                                
                            </tr>
                        @endforeach
                    </table>
                </div>
        </section>
    </main>
@endsection