@extends("layout")
@section("content")
    <main class="container py-4 px-5">
        <section>
            <h1>Autó hozzáadása</h1>
            <div class="row">
                <div class="col-md">
                    <div class="card-body">
                        <form action="/autok" method="post">
                            @csrf
                            <label class="form-label fw-bold mt-4" for="rendszam">Autó rendszáma: </label>
                            <input class="form-control" type="text" name="rendszam" id="rendszam" value="{{old('rendszam')}}" placeholder="PL: AA AA-123">
                            @error("rendszam")
                                <p class="text-danger">{{$message}}</p>
                            @enderror

                            <label for="marka" class="form-label fw-bold mt-4">Autó márkája: </label>
                            <input type="text" class="form-control" name="marka" id="marka" value="{{old('marka')}}" placeholder="PL: Ford">

                            @error("marka")
                                <p class="text-danger">{{$message}}</p>
                            @enderror

                            <label for="tipus" class="form-label fw-bold mt-4">Autó típusa: </label>
                            <input type="text" class="form-control" name="tipus" id="tipus" value="{{old('tipus')}}" placeholder="PL: Focus">

                            @error('tipus')
                                <p class="text-danger">{{$message}}</p>
                            @enderror
                            <label for="evjarat" name='evjarat' class="form-label mt-4 fw-bold">Autó évjárata: </label>
                            <select name="evjarat" id="evjarat" class="form-select">
                                @for($i = 2026; $i >= 1960; $i--) {
                                    <option value="{{$i}}" @if(old('evjarat') == $i) selected @endif>{{$i}}</option>
                                } 
                                @endfor
                            </select>

                            <label for="szin" class="form-label fw-bold mt-4">Autó színe: </label>
                            <input type="text" class="form-control" name="szin" id="szin" value="{{old('szin')}}" placeholder="Pl.: olajzöld">

                            <button class="btn btn-dark mt-4" type="submit">Elküld</button>
                        </form>
                    </div>
                </div>
            
                <div class="col-md">
                    <table class="table table-bordered table-striped">
                        <tr>
                            <th>Rendszám</th>
                            <th>Márka</th>
                            <th>Típus</th>
                            <th>Évjárat</th>
                            <th>Szín</th>
                        </tr>
                        @foreach ($result as $row)
                            <tr>
                                <td>{{$row->rendszam}}</td>
                                <td>{{$row->marka}}</td>
                                <td>{{$row->tipus}}</td>
                                <td>{{$row->evjarat}}</td>
                                <td>{{$row->szin}}</td>
                            </tr>
                        @endforeach
                    </table>
                </div>
        </section>
    </main>
@endsection